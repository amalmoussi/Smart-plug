public class Prise {
    private boolean etat;
    private double ConsommationCourant;

    public Prise(boolean etat,double consommationCourant)
    {
        this.etat=etat;
        this.ConsommationCourant=consommationCourant;
    }

    public boolean isEtat() {
        return etat;
    }

    public void setEtat(boolean etat) {
        this.etat = etat;
    }

    public double getConsommationCourant() {
        return ConsommationCourant;
    }

    public void setConsommationCourant(double consommationCourant) {
        ConsommationCourant = consommationCourant;
    }
}
