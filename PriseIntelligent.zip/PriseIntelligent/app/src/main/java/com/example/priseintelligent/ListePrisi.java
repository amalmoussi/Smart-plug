package com.example.priseintelligent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class ListePrisi extends AppCompatActivity {
    ImageView four,micro,refrigedaire,tv,lampe,coffe,heater,iron;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_prisi);
        four=(ImageView) findViewById(R.id.four);
        micro=(ImageView) findViewById(R.id.micro);
        refrigedaire=(ImageView) findViewById(R.id.refrigedaire);

        tv=(ImageView) findViewById(R.id.tv);
        lampe=(ImageView) findViewById(R.id.lampe);
        coffe=(ImageView) findViewById(R.id.coffee);
        heater=(ImageView) findViewById(R.id.heater);
        iron=(ImageView) findViewById(R.id.iron);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal_700)));
        getSupportActionBar().setTitle("");
        lampe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomLampe","lampe");
                startActivity(intent);
            }
        });
        heater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomHeater","chauffage");
                startActivity(intent);
            }
        });
        iron.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomIron","fer");
                startActivity(intent);
            }
        });
        coffe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomCoffee","machine à café");
                startActivity(intent);
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomFour","four");
                startActivity(intent);
            }
        });
        micro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomMicro","micro onde");
                startActivity(intent);
            }
        });
        refrigedaire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomRefrigedaire","refrigedaire");
                startActivity(intent);
            }
        });
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(ListePrisi.this, CommanderPrisi.class);
                intent.putExtra("nomTv","tv");
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.sidemenu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.dashbord:
                Intent intent = new Intent(ListePrisi.this,dashbord.class);
                startActivity(intent);
                break;
            case R.id.Prisi:
                Intent intent1 = new Intent(ListePrisi.this,ListePrisi.class);
                startActivity(intent1);
                break;
            case R.id.deconnecter:
                Intent intent2 = new Intent(ListePrisi.this,Login.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent2);
        }
        return super.onOptionsItemSelected(item);
    }
}