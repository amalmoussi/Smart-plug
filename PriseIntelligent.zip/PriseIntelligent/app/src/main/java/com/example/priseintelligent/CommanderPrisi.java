package com.example.priseintelligent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class CommanderPrisi extends AppCompatActivity {
    DatabaseReference mydb;
    ImageView imageView,deconnecter,timer;
    TextView title,msg,ConsommationValue,date,value3;
    ConstraintLayout constraintLayout;
    private int mYear, mMonth, mDay, mHour, mMinute;
    int nbreClique=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commande);
        title=(TextView)findViewById(R.id.title);
        ConsommationValue=(TextView)findViewById(R.id.value);
        date=(TextView)findViewById(R.id.Value1);
        value3=(TextView)findViewById(R.id.value3);
        imageView=(ImageView)findViewById(R.id.imageView);
        timer=(ImageView)findViewById(R.id.timer);
        msg=findViewById(R.id.msg);
        constraintLayout=findViewById(R.id.layout);
        String four = "";
        String micro = "";
        String tv  = "";
        String refrigerateur = "";
        String lampe = "";
        String coffee = "";
        String heater = "";
        String iron = "";
        Intent intentFour = getIntent();
        Intent intentHeater = getIntent();
        Intent intentIron = getIntent();
        Intent intentMicro = getIntent();
        Intent intentTv = getIntent();
        Intent intentRefrigerateur = getIntent();
        Intent intentLampe = getIntent();
        Intent intentCoffee = getIntent();

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal_700)));
        getSupportActionBar().setTitle("");

        mydb= FirebaseDatabase.getInstance().getReference().child("PriseIntelligent");
        try {

            mydb.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.
                    String tension = dataSnapshot.child("tension").getValue().toString();
                    boolean etat= (boolean) dataSnapshot.child("EtatRelais").getValue();

                    ConsommationValue.setText(tension);

                   if(etat)
                    {
                        msg.setText("Prisi on");
                        constraintLayout.setBackgroundResource(R.color.white);
                    }
                    else
                    {
                        msg.setText("Prisi off");
                        constraintLayout.setBackgroundResource(R.color.text_shadow);
                    }


                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value

                }
            });
        } catch(Exception e)
        {


        }

    timer.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(CommanderPrisi.this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {
                            String date1= date.getText().toString();
                            date.setText(date1+" "+hourOfDay + ":" + minute);
                            Map<String,Object> map=new HashMap<>();
                            map.put("date",date.getText().toString());
                            mydb.updateChildren(map)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                                if (msg.getText().toString()=="Prisi off")
                                                {
                                                    value3.setText("votre prisi va allumer à");
                                                }
                                                else
                                                {
                                                    value3.setText("votre prisi va atteint à");
                                                }
                                        }
                                    });
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
            DatePickerDialog datePickerDialog = new DatePickerDialog(CommanderPrisi.this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);

            datePickerDialog.show();


        }

    });
    imageView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
           Map<String,Object> map=new HashMap<>();

            nbreClique++;
            if(nbreClique%2!=0)
            {
                map.put("EtatRelais",false);
                mydb.updateChildren(map)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                constraintLayout.setBackgroundResource(R.color.text_shadow);
                                msg.setText("Prisi off");
                            }
                        });
            }
            else
            {
                map.put("EtatRelais",true);
                mydb.updateChildren(map)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                constraintLayout.setBackgroundResource(R.color.white);
                                msg.setText("Prisi on");
                            }
                        });


            }
        }
    });

        if (intentHeater.hasExtra("nomHeater"))
        {
            heater = intentHeater.getStringExtra("nomHeater");
            title.setText("Commander votre "+heater);
        }
        if (intentFour.hasExtra("nomFour"))
        {
            four = intentFour.getStringExtra("nomFour");
            title.setText("Commander votre "+four);
        }
        if (intentIron.hasExtra("nomIron"))
        {
            iron = intentIron.getStringExtra("nomIron");
            title.setText("Commander votre "+iron);
        }
        if (intentLampe.hasExtra("nomLampe"))
        {
            lampe = intentLampe.getStringExtra("nomLampe");
            title.setText("Commander votre "+lampe);
        }
        if (intentCoffee.hasExtra("nomCoffee"))
        {
            coffee = intentCoffee.getStringExtra("nomCoffee");
            title.setText("Commander votre "+coffee);
        }
        if (intentRefrigerateur.hasExtra("nomRefrigedaire"))
        {
            refrigerateur = intentRefrigerateur.getStringExtra("nomRefrigedaire");
            title.setText("Commander votre "+refrigerateur);
        }
        if (intentTv.hasExtra("nomTv"))
        {
            tv = intentTv.getStringExtra("nomTv");
            title.setText("Commander votre "+tv);
        }
        if (intentMicro.hasExtra("nomMicro"))
        {
            micro = intentMicro.getStringExtra("nomMicro");
            title.setText("Commander votre "+micro);
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.sidemenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.dashbord:
                Intent intent = new Intent(CommanderPrisi.this,dashbord.class);
                startActivity(intent);
                break;
            case R.id.Prisi:
                Intent intent1 = new Intent(CommanderPrisi.this,ListePrisi.class);
                startActivity(intent1);
                break;
            case R.id.deconnecter:
                Intent intent2 = new Intent(CommanderPrisi.this,Login.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent2);
        }
        return super.onOptionsItemSelected(item);
    }
}