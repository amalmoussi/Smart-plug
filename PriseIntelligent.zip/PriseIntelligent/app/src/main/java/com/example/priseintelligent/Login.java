package com.example.priseintelligent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.priseintelligent.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    TextView text2;
    Intent intent;
    EditText et_username,et_password;
    Button btn_login;
    TextView erreur,forget;
    ActivityLoginBinding binding;
    FirebaseAuth firebaseAuth;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog=new ProgressDialog(this);
        text2=findViewById(R.id.text2);
        et_username = (EditText)findViewById(R.id.et_username);
        et_password = (EditText)findViewById(R.id.et_password);
        btn_login = (Button) findViewById(R.id.btn_login);
        forget = (TextView) findViewById(R.id.forget);
        erreur=(TextView)findViewById(R.id.erreur);
        text2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent= new Intent(Login.this, MainActivity.class);
                startActivity(intent);
            }
        });
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               String email=binding.etUsername.getText().toString().trim();
               String password=binding.etPassword.getText().toString().trim();
                progressDialog.show();
               firebaseAuth.signInWithEmailAndPassword(email,password)
                       .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                           @Override
                           public void onSuccess(AuthResult authResult) {
                               progressDialog.cancel();
                               //Toast.makeText(Login.this,"Login success",Toast.LENGTH_LONG).show();

                              intent= new Intent(Login.this, ListePrisi.class);
                               startActivity(intent);
                           }
                       })
                       .addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull Exception e) {
                               progressDialog.cancel();
                               erreur.setText(e.getMessage());
                           }
                       });
            }
        });
        binding.forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.etUsername.getText().toString();
                if (validateUser()) {
                    progressDialog.setTitle("Sending Mail");
                    progressDialog.show();
                    firebaseAuth.sendPasswordResetEmail(email)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    progressDialog.cancel();
                                    Toast.makeText(Login.this, "Email sent", Toast.LENGTH_LONG).show();

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    progressDialog.cancel();
                                    Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_LONG).show();

                                }
                            });
                }
            }
        });
    }

    private boolean validateUser(){
        String user = et_username.getText().toString();
        if(user.isEmpty()){
            et_username.setError("Le champ username ne peut pas être vide");
            return false;
        }else{
            et_username.setError(null);
            return true;
        }
    }

    private boolean validatePassword(){
        String pass = et_password.getText().toString();
        if(pass.isEmpty()){
            et_password.setError("Le champ password ne peut pas être vide");
            return false;
        }else{
            et_password.setError(null);
            return true;
        }
    }
}