package com.example.priseintelligent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.example.priseintelligent.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MainActivity extends AppCompatActivity {
    EditText et_name;
    EditText et_email;
    EditText et_password;
    TextView erreur,success,seConnecter;
    Intent intent;
    Button btn_login;
    FirebaseFirestore firestore;
    ActivityMainBinding binding;
    FirebaseAuth firebaseAuth;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        et_name = findViewById(R.id.Nom);
        et_email = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        btn_login = findViewById(R.id.btn_login);
        erreur = findViewById(R.id.erreur);
        success = findViewById(R.id.success);
        seConnecter = findViewById(R.id.seConnecter);
        firestore = FirebaseFirestore.getInstance();
        Map<String, Object> users = new HashMap<>();
        seConnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, Login.class);
                startActivity(intent);
            }
        });
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.etUsername.getText().toString().trim();
                String password = binding.etPassword.getText().toString();
                String name = binding.Nom.getText().toString();
                progressDialog.show();


                    firebaseAuth.createUserWithEmailAndPassword(email,password)
                            .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                @Override
                                public void onSuccess(AuthResult authResult) {
                                    erreur.setText("");
                                    success.setText("Votre compte est crée avec succés");
                                    seConnecter.setText("se Connecter");
                                    seConnecter.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
                                    progressDialog.cancel();

                                    firestore.collection("Users")
                                            .document(FirebaseAuth.getInstance().getUid())
                                            .set(new Users(name, email));

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    erreur.setText(e.getMessage());
                                    progressDialog.cancel();

                                }
                            });





            }

        });
    }

       boolean isPass(){
           String pass = et_password.getText().toString();
           if (pass.isEmpty()) {
               et_password.setError("champs obligatoire\"");
               return false;
           } else {
               et_password.setError(null);
               return true;
           }
    }

    private boolean validateUser() {
        String user = et_name.getText().toString();
        if (user.isEmpty()) {
            et_name.setError("champs obligatoire\"");
            return false;
        } else {
            et_name.setError(null);
            return true;
        }
    }
    private boolean validateEmail() {
        String email = et_email.getText().toString();
        if (email.isEmpty()) {
            et_email.setError("Enter valid email!");
            return false;
        } else {
            et_email.setError(null);
            return true;
        }

    }
}